class ImageData {
  String path;

  String title;

  String date;

  ImageData(this.path, this.title, this.date);
}
